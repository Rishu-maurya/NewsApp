import { Link, NavLink } from 'react-router-dom';
import '../../style/Dashboard.css';
import './publisher.css';

const linkClass = ({ isActive }) => `pub-link${isActive ? ' is-active' : ''}`;

export default function PublisherLayout({ session, title, subtitle, children }) {
    return (
        <div className="dash">
            <header className="dash__bar">
                <div className="dash__bar-inner">
                    <span className="dash__brand">News Platform</span>
                    <div className="dash__user">
                        {/* name + role badge open the signed-in user's profile */}
                        <Link
                            to="/profile"
                            className="dash__profile"
                            title="Open your profile"
                            aria-label={`${session.user.name}, open your profile`}
                        >
                            <span className="dash__avatar" aria-hidden="true">
                                {session.user.name.trim().charAt(0).toUpperCase()}
                            </span>
                            <span className="dash__name">{session.user.name}</span>
                            <span className="dash__role">Publisher</span>
                        </Link>
                    </div>
                </div>
            </header>

            <div className="pub">
                <aside className="pub__side">
                    <nav aria-label="Publisher menu">
                        <NavLink to="/publisher" end className={linkClass}>Overview</NavLink>
                        <NavLink to="/publisher/write" className={linkClass}>Write story</NavLink>
                        <NavLink to="/publisher/stories" className={linkClass}>My stories</NavLink>
                    </nav>
                </aside>

                <main className="pub__main">
                    <h1>{title}</h1>
                    <p className="dash__sub">{subtitle}</p>
                    {children}
                </main>
            </div>
        </div>
    );
}
