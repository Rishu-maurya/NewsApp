import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import SiteLayout from "../../components/layout/SiteLayout";
import ArticleCard from "../../components/news/ArticleCard";
import {
  getCategories,
  getPublishedArticles,
} from "../../services/articleService";
import NotFound from "../NotFound/NotFound";
import "../../style/CategoryDetail.css";

export default function CategoryDetail({ session, onLogout }) {
  const { category: slug } = useParams();
  const [categories, setCategories] = useState([]);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    Promise.all([getCategories(), getPublishedArticles()])
      .then(([categoryList, articleList]) => {
        if (cancelled) return;
        setCategories(categoryList);
        setArticles(articleList);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  const category = categories.find((item) => item.slug === slug);
  if (!category) return <NotFound session={session} onLogout={onLogout} />;

  const stories = articles.filter(
    (article) => article.category === category.name,
  );

  return (
    <SiteLayout session={session} onLogout={onLogout}>
      <div className="s-category-detail">
        <Link to="/categories" className="s-back">
          All categories
        </Link>
        <section className="s-page-intro">
          <p className="s-eyebrow">Category</p>
          <h1 className="s-h1">{category.name}</h1>
          <p className="s-sub">
            {stories.length
              ? `${stories.length} ${stories.length === 1 ? "story" : "stories"} in ${category.name}.`
              : `There are no published ${category.name.toLowerCase()} stories yet.`}
          </p>
        </section>

        {stories.length ? (
          <div className="s-grid">
            {stories.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                session={session}
              />
            ))}
          </div>
        ) : (
          <div className="s-empty">
            <p>New stories will appear here after editorial review.</p>
            <Link to="/categories" className="s-btn">
              Explore other categories
            </Link>
          </div>
        )}
      </div>
    </SiteLayout>
  );
}
